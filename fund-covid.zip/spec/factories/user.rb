FactoryBot.define do
  
  factory :user do
    email { 'test@gmail.com' }
    password  { 'test123' }
  end

end